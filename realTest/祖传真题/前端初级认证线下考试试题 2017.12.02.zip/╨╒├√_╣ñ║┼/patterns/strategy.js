/**
 * 策略模式的定义是：定义一系列的算法，把它们一个个封装起来，并且使它们可以相互替换。
 * 策略模式具有许多优点:
 * 1. 策略模式利用组合，委托等技术和思想，有效的避免很多if条件语句。
 * 2. 策略模式提供了开放-封闭原则，使代码更容易理解和扩展。
 * 3. 策略模式中的代码可以复用。
 *
 * 本题模拟商家委托指定快递公司发货，用策略模式改造实现
 **/


//快递
var Express = function(){
}
Express.prototype.deliver = function(){
	console.log(this.name + ": 正在派件...");
}

var shunfeng = function(){
	this.name = "顺风快递";
}
shunfeng.prototype = new Express();

var yuantong = function(){
	this.name = "圆通快递";
}
yuantong.prototype = new Express();

var shentong = function(){
	this.name = "申通快递";
}
shentong.prototype = new Express();

var zhongtong = function(){
	this.name = "中通快递";
}
zhongtong.prototype = new Express();

var yunda = function(){
	this.name = "韵达快递";
}
yunda.prototype = new Express();

var tiantian = function(){
	this.name = "天天快递";
}
tiantian.prototype = new Express();

var jingdong = function(){
	this.name = "京东快递";
}
jingdong.prototype = new Express();

//订单
var Order = function(express){
	this.express = express;
}

/*******************以下代码片段，改为策略模式实现*********************/
// 卖家
var Seller = function(){}
//发货
Seller.prototype.deliverGoods = function(order){
	var sender;
	if(order.express == "shunfeng"){
		sender = new shunfeng();
	}else if(order.express == "yuantong"){
		sender = new yuantong();
	}else if(order.express == "zhongtong"){
		sender = new zhongtong();
	}else if(order.express == "yunda"){
		sender = new yunda();
	}
	if(sender){
		sender.deliver();
	}else{
		console.log("不支持"+order.express);
	}
}

var order = new Order("yunda");
var seller = new Seller();
seller.deliverGoods(order);
/*******************以上代码片段，改为策略模式实现*********************/